require(["ecp.service", "ecp.utils.render", 'ecp.model'], function (ecpService, renderUtil, ecpModel) {
  "use strict";

  // 日志对象

  var log = ecpService.Log;

  /**
   * 声明函数对象.
   */
  var PageController = function () {
    //初始化页面
    this.initPage();
  };

  /**
   * 通过原型定义相关方法，比如渲染、赋值等等.
   */
  PageController.prototype = {
    /**
     * 初始化页面.
     */
    initPage: function () {
      //todo
    },
    /**
     * 渲染.
     * 基础控件渲染和统一渲染页面控件
     */
    render: function () {
      //渲染页面控件
      renderUtil.pageRender($.proxy(this.afterRender, this));
    },
    /**
     * 渲染后.
     */
    afterRender: function (map, base) {
      //通过指针调用控件ID即可获取控件对象
      base(this);
      //绑定事件
      this.bindEvent();
      this.loadData();
    },

    /**
     * 绑定事件.
     */
    bindEvent: function () {
      //@bindEvent
      //@bindEvent
      this.ecpbutton_2116_event();
      this.ecpbutton_8227_event();
    },

    /**
     * 获取页面数据模型.
     */
    loadData: function () {
      //@loadData
			//@loadData
    },

    /**
     * 绑定数据源.
     */
    bindDataSource: function () {
      this.dataSource = new ecpModel.DataSource();
      this.dataSource.dataModel = this.dataModel;
      this.dataSource.bind($("body"));
    },
    ecpbutton_2116_event: function () {
      var me = this;
      $("body").on("click", "#ecpbutton_2116", function (e) {
        window.location.href = "db82f45e-0668-4b75-aae9-2535fcd9ba01.html?sdkId=6a5de6ed2474446eefba58be5ac7cc2f";
      });
    },
    ecpbutton_8227_event: function () {
      var me = this;
      $("body").on("click", "#ecpbutton_8227", function (e) {
        window.location.href = "29ba6e40-fd02-4156-9019-c44f18c5e069.html?sdkId=6a5de6ed2474446eefba58be5ac7cc2f";
      });
    }
  };
  /**
   * 开始执行.
   */
  var controller = new PageController();
  controller.render();
});