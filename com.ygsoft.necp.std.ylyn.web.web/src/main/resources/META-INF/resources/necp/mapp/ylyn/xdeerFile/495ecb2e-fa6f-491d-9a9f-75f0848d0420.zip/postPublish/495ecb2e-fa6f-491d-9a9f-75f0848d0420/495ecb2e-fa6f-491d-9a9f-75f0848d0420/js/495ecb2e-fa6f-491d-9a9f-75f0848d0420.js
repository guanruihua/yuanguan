require(["ecp.service", "ecp.utils.render", 'ecp.model'], function (ecpService, renderUtil, ecpModel) {
  "use strict";

  // 日志对象

  var log = ecpService.Log;

  /**
   * 声明函数对象.
   */
  var PageController = function () {
    //初始化页面
    this.initPage();
  };

  /**
   * 通过原型定义相关方法，比如渲染、赋值等等.
   */
  PageController.prototype = {
    /**
     * 初始化页面.
     */
    initPage: function () {
      //todo
    },
    /**
     * 渲染.
     * 基础控件渲染和统一渲染页面控件
     */
    render: function () {
      //渲染页面控件
      renderUtil.pageRender($.proxy(this.afterRender, this));
    },
    /**
     * 渲染后.
     */
    afterRender: function (map, base) {
      //通过指针调用控件ID即可获取控件对象
      base(this);
      //绑定事件
      this.bindEvent();
      this.loadData();
    },

    /**
     * 绑定事件.
     */
    bindEvent: function () {
      //@bindEvent
      //@bindEvent
      this.ecplabel_1420_event();
      this.ecplabel_0415_event();
    },

    /**
     * 获取页面数据模型.
     */
    loadData: function () {
      //@loadData			
			var me = this;
			var coms = document.querySelectorAll("[com='ecp-select'][value]") || []
			for(var i=0,len=coms.length; i<len; i++){
				var com = coms[i];
				var value = com.getAttribute("value")
				if (me[com.id] && value != null) {
					me[com.id].value(value);
				}
			}
			//@loadData
    },

    /**
     * 绑定数据源.
     */
    bindDataSource: function () {
      this.dataSource = new ecpModel.DataSource();
      this.dataSource.dataModel = this.dataModel;
      this.dataSource.bind($("body"));
    },
    ecplabel_1420_event: function () {
      var me = this;
      $("body").on("click", "#ecplabel_1420", function (e) {
        require(["ecp.utils.window"], function (winUtils) {
          winUtils.openWindow("28a9dc63-db09-4e3a-88c3-d67c3283ab2b.html?sdkId=6a5de6ed2474446eefba58be5ac7cc2f");
        });
      });
    },
    ecplabel_0415_event: function () {
      var me = this;
      $("body").on("click", "#ecplabel_0415", function (e) {
        window.location.href = "29ba6e40-fd02-4156-9019-c44f18c5e069.html?sdkId=6a5de6ed2474446eefba58be5ac7cc2f";
      });
    }
  };
  /**
   * 开始执行.
   */
  var controller = new PageController();
  controller.render();
});